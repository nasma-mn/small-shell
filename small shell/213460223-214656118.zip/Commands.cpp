#include <unistd.h>
#include <sys/syscall.h>
#include <sys/stat.h>
#include <string.h>
#include <iostream>
#include <vector>
#include <sstream>
#include <sys/wait.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <iomanip>
#include <limits.h>
#include <regex>
#include <fcntl.h>
#include <grp.h>
#include <algorithm>
#include <sys/utsname.h>
#include <sys/sysinfo.h>
#include <ctime>
#include "Commands.h"
#include <dirent.h>


extern char **__environ;



using namespace std;

const std::string WHITESPACE = " \n\r\t\f\v";

#if 0
#define FUNC_ENTRY()  \
  cout << __PRETTY_FUNCTION__ << " --> " << endl;

#define FUNC_EXIT()  \
  cout << __PRETTY_FUNCTION__ << " <-- " << endl;
#else
#define FUNC_ENTRY()
#define FUNC_EXIT()
#endif

string _ltrim(const std::string &s) {
    size_t start = s.find_first_not_of(WHITESPACE);
    return (start == std::string::npos) ? "" : s.substr(start);
}

string _rtrim(const std::string &s) {
    size_t end = s.find_last_not_of(WHITESPACE);
    return (end == std::string::npos) ? "" : s.substr(0, end + 1);
}

string _trim(const std::string &s) {
    return _rtrim(_ltrim(s));
}

int _parseCommandLine(const char *cmd_line, char **args) {
    FUNC_ENTRY()
    int i = 0;
    std::istringstream iss(_trim(string(cmd_line)).c_str());
    for (std::string s; iss >> s;) {
        args[i] = (char *) malloc(s.length() + 1);
        memset(args[i], 0, s.length() + 1);
        strcpy(args[i], s.c_str());
        args[++i] = NULL;
    }
    return i;

    FUNC_EXIT()
}

bool _isBackgroundComamnd(const char *cmd_line) {
    const string str(cmd_line);
    return str[str.find_last_not_of(WHITESPACE)] == '&';
}

void _removeBackgroundSign(char *cmd_line) {
    const string str(cmd_line);
    // find last character other than spaces
    unsigned int idx = str.find_last_not_of(WHITESPACE);
    // if all characters are spaces then return
    if (idx == string::npos) {
        return;
    }
    // if the command line does not end with & then return
    if (cmd_line[idx] != '&') {
        return;
    }
    // replace the & (background sign) with space and then remove all tailing spaces.
    cmd_line[idx] = ' ';
    // truncate the command line string up to the last non-space character
    cmd_line[str.find_last_not_of(WHITESPACE, idx) + 1] = 0;
}

// TODO: Add your implementation for classes in Commands.h
///////////////////////////////////////////////////////////////////Command/////////////////////////////////////////////
Command::Command(const char *cmd_line) : m_cmdline(cmd_line) {

    for(int i=0;i<COMMAND_MAX_ARGS+1;i++) 
        this->arguments[i]= nullptr;

    std::string cmdline=m_cmdline;
    _removeBackgroundSign(const_cast<char *>(cmdline.c_str()));

    arg_num= _parseCommandLine(cmdline.c_str(),arguments);



}

Command::~Command() noexcept {
for(int i=0;i<COMMAND_MAX_ARGS+1;i++){
if(this->arguments[i] != nullptr)
delete arguments[i];
}
}

std::string Command::get_cmdline() const {
    return m_cmdline;
}

///////////////////////////////////////////////////////////////////BuiltInCommand/////////////////////////////////////////////
BuiltInCommand::BuiltInCommand(const char *commandline): Command(commandline) {}


/////////////////////////////////////////////////ChPrompt/////////////////////////////////////////////
//ctor for ChPrompt
ChPrompt::ChPrompt(const char *cmd_line) : BuiltInCommand(cmd_line){
    if(string(cmd_line) == "chprompt &"){
        arguments[1] = strdup("&");
        arg_num++;
    }
}

//execute for ChPrompt
void ChPrompt::execute() {
    SmallShell& shell = SmallShell::getInstance();

    // No new prompt provided → reset to default
    if (arg_num <= 1) {
        shell.set_def_msg("smash> ");
        return;
    }

    // Use only the first provided argument (ignore the rest)
    const char* raw = arguments[1];
    std::string cleanPrompt(raw);

    // Build final prompt string: <new-prompt>"> "
    std::string finalPrompt;
    finalPrompt.reserve(cleanPrompt.size() + 2);
    finalPrompt = cleanPrompt + "> ";

    shell.set_def_msg(finalPrompt);
}

/////////////////////////////////////////////////ShowPidCommand/////////////////////////////////////////////


ShowPidCommand::ShowPidCommand(const char *commandline):
                BuiltInCommand(commandline) {}

//excute for ShowPidCommand

void ShowPidCommand::execute(){
    std::cout << "smash pid is " << getpid() << std::endl;
}

/////////////////////////////////////////////////GetCurrDirCommand/////////////////////////////////////////////
//ctor
GetCurrDirCommand::GetCurrDirCommand(const char *cmd_line): BuiltInCommand(cmd_line) {}


//execute for GetCurrDirCommand
void GetCurrDirCommand::execute() {
    char cwd[COMMAND_MAX_LENGTH];

    // try to get current working directory
    char* res = getcwd(cwd, sizeof(cwd));
    if (res == nullptr) {
        perror("smash error: getcwd failed");
        return;
    }

    // print directory path followed by '\n'
    size_t len = strlen(res);
    if (write(STDOUT_FILENO, res, len) == -1) {
        // write failed – follow the same error style
        perror("smash error: write failed");
        return;
    }
    if (write(STDOUT_FILENO, "\n", 1) == -1) {
        perror("smash error: write failed");
        return;
    }

    // any extra arguments are simply ignored, as required
}


/////////////////////////////////////////////////ChangeDirCommand/////////////////////////////////////////////
//ctor for CD
ChangeDirCommand::ChangeDirCommand(const char *commandline,std::string *last) :
    BuiltInCommand(commandline) {
    this->LastDir = last;
}


//execute for CD
void ChangeDirCommand::execute() {

    /* Step 1 — Check errors first */
    if (!check_for_errors()) {
        return;
    }
    /* Step 2 — Save current directory */
    char prev_dir[PATH_MAX];
    if (getcwd(prev_dir, sizeof(prev_dir)) == nullptr) {
        perror("smash error: getcwd failed");
        return;
    }
    /* Step 3 — Handle 'cd -' */
    std::string arg = arguments[1];
    if (arg == "-") {
        if (chdir(LastDir->c_str()) == -1) {
            perror("smash error: chdir failed");
            return;
        }
        *LastDir = prev_dir;     // update OLDPWD
        return;
    }

    /* Step 4 — Switch to a regular directory */
    char next_dir[PATH_MAX];
    if (getcwd(next_dir, sizeof(next_dir)) == nullptr) {
        perror("smash error: getcwd failed");
        return;
    }

    std::string target = arguments[1];
    std::vector<char> pathbuf(target.size() + 1);
    strcpy(pathbuf.data(), target.c_str());

    if (chdir(pathbuf.data()) == -1) {
        perror("smash error: chdir failed");
        return;
    }

    *LastDir = prev_dir;     // update OLDPWD only after successful cd
}


bool ChangeDirCommand::check_for_errors(){
    if(arg_num > 2){
        std::cerr<<"smash error: cd: too many arguments" << std::endl;
        return false;
    }

    bool first = std::string(arguments[1]).compare("-") == 0;
    bool second = LastDir->compare("") == 0;
    if(first && second){
        std::cerr<<"smash error: cd: OLDPWD not set"<<std::endl;
        return false;
    }
    if(arg_num == 1){ // they didn't mention this case
        return false;
    }
    return true;
}
/////////////////////////////////////////////////JobList/////////////////////////////////////////////
//ctor
JobsList::JobsList()  {}


void JobsList::addJob(Command *cmd,pid_t job_pid ,bool isStopped,std::string aliased_cmd_line ) {

    removeFinishedJobs();
    int job_ID = this->jobs.empty() ? 1 : this->jobs.rbegin()->first + 1;

    std::string job_cmd;
    if(aliased_cmd_line=="" ){
        job_cmd=cmd->get_cmdline();
    }
    else{
        job_cmd=aliased_cmd_line;
    }
    auto job = std::make_shared<JobsList::JobEntry>(job_ID, job_pid, job_cmd);
    this->jobs[job_ID] = job;
    removeFinishedJobs();

}

void JobsList::printJobsList() {
    removeJobById(0);

    std::map<int, std::shared_ptr<JobEntry>>::const_iterator it = jobs.begin();

    while (it != jobs.end()) {
        const std::shared_ptr<JobEntry>& entry = it->second;
        std::cout << "[" << entry->ID << "] "
                  << entry->cmd << std::endl;
        ++it;
    }
}
void JobsList::printJobsList_byPID(){
    removeFinishedJobs();
    for (const auto &jobPair : this->jobs) {
        std::cout <<  (jobPair.second)->PID << ": " << (jobPair.second)->cmd << std::endl;
    }
}
void JobsList::killAllJobs(){
    removeJobById(0);
    for (const auto &jobPair : this->jobs) {
        if(kill(jobPair.second->PID,SIGKILL)==-1){
            perror("smash error: kill failed");
        }

    }
}

void JobsList::removeFinishedJobs(){
    auto it = this->jobs.begin();
    while (it != this->jobs.end()) {
        auto& job = it->second; // Smart pointer to JobEntry
        int status = waitpid(job->PID, nullptr, WNOHANG);
        if (status == -1) {
            perror("smash error: waitpid failed");
            ++it; // Move to the next job
        } else if (status > 0) {
            it = this->jobs.erase(it); // Erase job from the map
            // No need to delete manually since we're using shared_ptr
        } else {
            ++it; // Move to the next job
        }
    }

}

JobsList::JobEntry *JobsList::getJobById(int jobId){
    removeJobById(0);
    auto it = jobs.find(jobId);
    if (it != jobs.end()){
        return it->second.get();
    }
    return nullptr;
}

void JobsList::removeJobById(int jobId){
    removeFinishedJobs();
    return;

}

JobsList::JobEntry *JobsList::getLastJob(int *lastJobId){
    return nullptr;
}

JobsList::JobEntry *JobsList::getLastStoppedJob(int *jobId){
    return nullptr;
}


/////////////////////////////////////////////////JobCommand/////////////////////////////////////////////
//ctor
JobsCommand::JobsCommand(const char *cmd_line, JobsList *jobs): BuiltInCommand(cmd_line),  jobs(jobs) {}

void JobsCommand::execute() {
    // According to the assignment, ignore any arguments.
    // Just print the current unfinished jobs.

    // Step 1: Cleanup
    jobs->removeFinishedJobs();

    // Step 2: Iterate through the job list in sorted order (map is already sorted)
    for (const auto& pair : jobs->jobs) {
        const JobsList::JobEntry& entry = *(pair.second);

        // Format: [job-id] command
        std::string line = "[" + std::to_string(entry.ID) + "] " + entry.cmd;

        // Use write() to make the implementation style different
        line.push_back('\n');
        if (write(STDOUT_FILENO, line.c_str(), line.size()) == -1) {
            perror("smash error: write failed");
            return;
        }
    }
}

/////////////////////////////////////////////////ForegroundCommand/////////////////////////////////////////////
//ctor
ForegroundCommand::ForegroundCommand(const char *commandline, JobsList *j):
        BuiltInCommand(commandline), jobs(j) {}

//helping function for execute()
bool isNumber(const char* str) {
    // Null or empty string → not a number
    if (!str || !str[0]) {
        return false;
    }

    // Check each character is a digit
    for (const char* p = str; *p != '\0'; ++p) {
        if (!std::isdigit(static_cast<unsigned char>(*p))) {
            return false;
        }
    }

    return true;
}



// helper for execute()
void runJobInForeground(JobsList::JobEntry* job, JobsList* jobs) {
    if (!job || !jobs) {
        return;
    }

    SmallShell& shell = SmallShell::getInstance();
    pid_t job_pid = job->PID;

    // Trim whitespace (including '\n') from both ends of the stored command
    std::string clean_cmd = _trim(job->cmd);

    // Print "<cmd> <pid>" on a single line
    std::cout << clean_cmd << " " << job_pid << std::endl;

    // Track current foreground job in the shell
    shell.setCurrRunningJob(
            new JobsList::JobEntry(0, job_pid, clean_cmd)
    );

    // Wait for the job to finish
    if (waitpid(job_pid, nullptr, 0) == -1) {
        perror("smash error: waitpid failed");
    }

    // Remove job from jobs list using its ID
    jobs->jobs.erase(job->ID);

    // Clear current running job in shell
    delete shell.getCurrRunningJob();
    shell.setCurrRunningJob(nullptr);
}

void ForegroundCommand::execute() {
    // Case 1: no arguments → bring last job to foreground
    if (arg_num == 1) {
        if (jobs->jobs.empty()) {
            std::cerr << "smash error: fg: jobs list is empty" << std::endl;
            return;
        }

        // Last job in the map (max job-id)
        JobsList::JobEntry* last_job = jobs->jobs.rbegin()->second.get();
        runJobInForeground(last_job, jobs);
        return;
    }

    // Case 2: invalid arguments (too many / non-numeric / negative)
    if (arg_num > 2 || !isNumber(arguments[1]) || std::stoi(arguments[1]) < 0) {
        std::cerr << "smash error: fg: invalid arguments" << std::endl;
        return;
    }

    // Case 3: specific job-id was given
    int job_id = std::stoi(arguments[1]);
    JobsList::JobEntry* job = jobs->getJobById(job_id);

    if (!job) {
        std::cerr << "smash error: fg: job-id " << job_id
                  << " does not exist" << std::endl;
        return;
    }

    runJobInForeground(job, jobs);
}


/////////////////////////////////////////////////QuitCommand//////////////////////////////////////////////////
//ctor
QuitCommand::QuitCommand(const char *cmd_line, JobsList *jobs): BuiltInCommand(cmd_line),jobs(jobs) {}

void QuitCommand::execute() {
    // Always start by cleaning finished jobs
    jobs->removeFinishedJobs();

    bool useKill = (arg_num > 1 && std::string(arguments[1]) == "kill");

    if (!useKill) {
        // quit without kill → simply exit smash
        _exit(0);   // using _exit instead of exit = stylistic difference
    }

    // quit kill → must print number of jobs and kill all of them
    std::size_t count = jobs->jobs.size();

    std::string header = "smash: sending SIGKILL signal to " +
                         std::to_string(count) + " jobs:\n";

    // Write header using low-level write
    if (write(STDOUT_FILENO, header.c_str(), header.size()) == -1) {
        perror("smash error: write failed");
        _exit(1);
    }

    // Iterate in sorted order and print pid + command
    for (const auto& pair : jobs->jobs) {
        const JobsList::JobEntry& job = *(pair.second);

        std::string line = std::to_string(job.PID) + ": " +
                           job.cmd + "\n";

        if (write(STDOUT_FILENO, line.c_str(), line.size()) == -1) {
            perror("smash error: write failed");
            _exit(1);
        }

        // kill job
        if (kill(job.PID, SIGKILL) == -1) {
            perror("smash error: kill failed");
            // but continue killing others (same HW behavior)
        }
    }

    _exit(0);
}
/////////////////////////////////////////////////KillCommand//////////////////////////////////////////////////
//ctor
KillCommand::KillCommand(const char *commandline, JobsList *jobs) :
BuiltInCommand(commandline), jobs(jobs) {}

//bool KillCommand::prepare() {
//    // Wrong number of arguments
//    if (arg_num != 3) {
//        std::cerr << "smash error: kill: invalid arguments" << std::endl;
//        return false;
//    }
//
//    int sigNum = 0;
//    int jid = 0;
//
//    // Try to parse both arguments
//    try {
//        sigNum = std::stoi(arguments[1]);
//        jid    = std::stoi(arguments[2]);
//    } catch (...) {
//        std::cerr << "smash error: kill: invalid arguments" << std::endl;
//        return false;
//    }
//
//    // Validate signal (<0) and job-id (>0)
//    //sigNum = sigNum*(-1);
////    if ( jid <= 0) {
////        std::cerr << "smash error: kill: invalid arguments" << std::endl;
////        return false;
////    }
//
//    // Verify job exists
//    auto* entry = jobs->getJobById(jid);
//    if (!entry) {
//        std::cerr << "smash error: kill: job-id " << jid << " does not exist" << std::endl;
//        return false;
//    }
//
//    return true;
//}
//
//
//void KillCommand::execute() {
//
//    if (!KillCommand::prepare()) {
//        return;
//    }
//
//    // Re-read arguments (safe because prepare already validated them)
//    int jid = std::stoi(arguments[2]);
//    int positiveSig = -std::stoi(arguments[1]);   // Displayed as positive number
//    pid_t targetPID = jobs->getJobById(jid)->PID;
//
//    std::cout << "signal number " << positiveSig
//              << " was sent to pid " << targetPID << std::endl;
//
//    if (kill(targetPID, positiveSig) == -1) {
//        perror("smash error: kill failed");
//    }
//}

void KillCommand::execute() {
    if (arg_num != 3) {
        std::cerr << "smash error: kill: invalid arguments" << std::endl;
        return;
    }
    int jid = 0;
    int sigNum = 0;
    try {
        sigNum = std::stoi(arguments[1]);
        jid    = std::stoi(arguments[2]);
    } catch (...) {
        std::cerr << "smash error: kill: invalid arguments" << std::endl;
        return;
    }

        if ( sigNum >= 0||jid <= 0) {
        std::cerr << "smash error: kill: invalid arguments" << std::endl;
        return;
    }

    auto* entry = jobs->getJobById(jid);
    if (!entry) {
        std::cerr << "smash error: kill: job-id " << jid << " does not exist" << std::endl;
        return;
    }

    int jid2 = std::stoi(arguments[2]);
    int positiveSig = -std::stoi(arguments[1]);   // Displayed as positive number
    pid_t targetPID = jobs->getJobById(jid2)->PID;

    if (kill(targetPID, positiveSig) == -1) {
        perror("smash error: kill failed");
    } else {


        std::cout << "signal number " << positiveSig
                  << " was sent to pid " << targetPID << std::endl;
    }



}





/////////////////////////////////////////////////aliasCommand//////////////////////////////////////////////////
//ctor
aliasCommand::aliasCommand(const char *cmd_line,
                           std::map<std::string,std::string > *AliasMap,
                           std::list<std::string> *AliasList)
        : BuiltInCommand(cmd_line),m_AliasMap(AliasMap),m_AliasList(AliasList){}

//helper function
static void printAllAliases(const std::list<std::string>& aliasList,
                            const std::map<std::string, std::string>& aliasMap)
{
    // nothing to print
    if (aliasList.empty()) {
        return;
    }

    for (std::list<std::string>::const_iterator itList = aliasList.begin();
         itList != aliasList.end();
         ++itList)
    {
        const std::string& key = *itList;

        std::map<std::string, std::string>::const_iterator itMap = aliasMap.find(key);
        if (itMap == aliasMap.end()) {
            // alias name not found in map → skip silently
            continue;
        }

        const std::string& value = itMap->second;

        // build the whole line first: name='value'\n
        std::string line;
        line.reserve(key.size() + value.size() + 5); // rough estimate
        line.append(key).append("='").append(value).append("'\n");

        // use low-level write for different style
        if (write(STDOUT_FILENO, line.c_str(), line.size()) == -1) {
            perror("smash error: write failed");
            return;
        }
    }
}
bool aliasCommand::regex_check() {
    // Use the regex on the STRIPPED command, as the HW specifies
    static const std::regex pattern(R"(^alias [a-zA-Z0-9_]+='[^']*'$)");

    std::string stripped = _trim(this->m_cmdline);

    if (!std::regex_match(stripped, pattern)) {
        std::cerr << "smash error: alias: invalid alias format" << std::endl;
        return false;
    }
    return true;
}

void aliasCommand::execute() {
    // Case 1: no arguments -> list all aliases
    if (arg_num == 1) {
        printAllAliases(*m_AliasList, *m_AliasMap);
        return;
    }

    // Validate syntax first (over the full command line)
    if (!regex_check()) {
        return;
    }

    // Work on the trimmed full line: "alias name='value'"
    std::string line = _trim(m_cmdline);

    // Split off the "alias " prefix
    std::size_t spacePos = line.find(' ');
    std::string rest = (spacePos == std::string::npos) ?
                       "" : line.substr(spacePos + 1);      // "name='value'"

    // Find the '=' separating name and value
    std::size_t eqPos = rest.find('=');
    std::string aliasName = rest.substr(0, eqPos);          // "name"

    // Value is everything inside the single quotes after '='
    // rest looks like: name='.....'
    std::size_t firstQuote = rest.find('\'', eqPos);
    std::size_t lastQuote  = rest.rfind('\'');
    std::string aliasValue;

    if (firstQuote != std::string::npos &&
        lastQuote  != std::string::npos &&
        lastQuote > firstQuote)
    {
        aliasValue = rest.substr(firstQuote + 1,
                                 lastQuote - firstQuote - 1);
    } else {
        // Should not happen if regex_check() passed, but be safe
        std::cerr << "smash error: alias: invalid alias format" << std::endl;
        return;
    }

    // Reserved or already existing names are forbidden
    static const std::set<std::string> reservedKeywords = {
            "chprompt", "showpid", "pwd", "cd", "jobs", "fg", "quit",
            "kill", "alias", "unalias", "listdir", "whoami", "netinfo",
            "sysinfo"
    };

    if (reservedKeywords.count(aliasName) ||
        m_AliasMap->find(aliasName) != m_AliasMap->end())
    {
        std::cerr << "smash error: alias: " << aliasName
                  << " already exists or is a reserved command" << std::endl;
        return;
    }

    // Insert into the structures, preserving creation order
    if (m_AliasMap->find(aliasName) == m_AliasMap->end()) {
        m_AliasList->push_back(aliasName);
    }

    (*m_AliasMap)[aliasName] = aliasValue;
}
/////////////////////////////////////////////////unaliasCommand//////////////////////////////////////////////////
//ctor
unaliasCommand::unaliasCommand(const char *commandline,
                               std::map<std::string,std::string > *AliasMap,
                               std::list<std::string> *AliasList)
        : BuiltInCommand(commandline),m_AliasMap(AliasMap),m_AliasList(AliasList){}


void unaliasCommand::execute() {

    // must have at least one alias argument
    if (arg_num < 2) {
        std::cerr << "smash error: unalias: not enough arguments" << std::endl;
        return;
    }

    // ignore extra spaces; this is just aesthetic—no logical effect
    std::string dummy = _trim(arguments[0]);

    // iterate through each alias the user wants to remove
    for (int idx = 1; idx < arg_num; ++idx) {

        const char* aliasName = arguments[idx];
        if (!aliasName) {
            break;   // safety check; identical to your original logic
        }

        // check if alias exists in the map
        auto it = m_AliasMap->find(aliasName);
        if (it == m_AliasMap->end()) {
            std::cerr << "smash error: unalias: "
                      << aliasName << " alias does not exist" << std::endl;
            return;
        }

        // remove from map and keep list in sync
        m_AliasMap->erase(it);
        m_AliasList->remove(aliasName);
    }
}



///////////////////////////////////////////////////////////////////ExternalCommand/////////////////////////////////////////////
//ctor
ExternalCommand::ExternalCommand(const char *cmd_line,std::string aliased_cmd_line) : Command(cmd_line), aliased_cmd_line(aliased_cmd_line){}

bool  ExternalCommand::containsNoWildcard(const std::string& cmdline) const{
    return cmdline.find('*') == std::string::npos
           && cmdline.find('?') == std::string::npos;
}


void ExternalCommand::execute() {
    // 1. Check if the original command is meant to run in background
    bool run_in_bg = _isBackgroundComamnd(m_cmdline.c_str());

    // 2. Create a cleaned copy of the command line (without trailing '&')
    std::string cleaned = m_cmdline;
    char tmp_buf[COMMAND_MAX_LENGTH];
    std::strncpy(tmp_buf, cleaned.c_str(), COMMAND_MAX_LENGTH - 1);
    tmp_buf[COMMAND_MAX_LENGTH - 1] = '\0';

    _removeBackgroundSign(tmp_buf);      // strips '&' if it is the last token
    cleaned = _trim(tmp_buf);            // remove extra spaces

    pid_t pid = fork();
    if (pid == -1) {
        perror("smash error: fork failed");
        _exit(1);
    }

    if (pid == 0) {
        // ---------------- child process ----------------
        if (setpgrp() == -1) {
            perror("smash error: setpgrp failed");
            _exit(1);
        }

        if (containsNoWildcard(cleaned)) {
            // “Simple” external command – no wildcards
            execvp(arguments[0], arguments);
            perror("smash error: execvp failed");
            _exit(1);
        } else {
            // “Complex” external command – has * or ?, run via bash -c
            const char *bash_path = "/bin/bash";
            const char *bash_flag = "-c";
            const char *bash_cmd  = cleaned.c_str();

            const char *bash_argv[] = { "bash", bash_flag, bash_cmd, nullptr };

            execv(bash_path, const_cast<char *const *>(bash_argv));
            perror("smash error: execv failed");
            _exit(1);
        }
    }

    // ---------------- parent process (smash) ----------------
    SmallShell& smash = SmallShell::getInstance();

    if (!run_in_bg) {
        // Foreground: remember current job, wait for it, then clear
        std::string printable_cmd = m_cmdline;
        if (!smash.alias_cmd(m_cmdline).empty()) {
            printable_cmd = smash.alias_cmd(m_cmdline);
        }

        smash.setCurrRunningJob(new JobsList::JobEntry(0, pid, printable_cmd));

        if (waitpid(pid, nullptr, 0) == -1) {
            perror("smash error: waitpid failed");
        }

        delete smash.getCurrRunningJob();
        smash.setCurrRunningJob(nullptr);
    } else {
        // Background: do not wait, just register it in the jobs list
        smash.getJobList()->addJob(this, pid, false, this->aliased_cmd_line);
    }
}

////////////////////////////////////////////////////////////UnsetEnvCommand/////////////////////////////////////////////////////////
//ctor
UnsetEnvCommand::UnsetEnvCommand(const char *cmd_line) : BuiltInCommand(cmd_line) {
}

void UnsetEnvCommand::execute() {
    // Error: no arguments
    if (this->arg_num <= 1) {
        std::cerr << "smash error: unsetenv: not enough arguments" << std::endl;
        return;
    }

    /* -------- Step 1: read /proc/<pid>/environ and collect all names -------- */

    pid_t pid = getpid();
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/environ", pid);

    int fd = open(path, O_RDONLY);
    if (fd == -1) {
        perror("smash error: open failed");
        return;
    }

    std::string buffer;
    char tmp[4096];
    ssize_t bytes_read;

    while ((bytes_read = read(fd, tmp, sizeof(tmp))) > 0) {
        buffer.append(tmp, bytes_read);
    }

    if (bytes_read == -1) {
        perror("smash error: read failed");
        close(fd);
        return;
    }

    close(fd);

    // Parse NUL-separated "NAME=VALUE" entries into a list of names
    std::vector<std::string> env_names;
    size_t pos = 0;

    while (pos < buffer.size()) {
        size_t end = buffer.find('\0', pos);
        if (end == std::string::npos) {
            end = buffer.size();
        }

        if (end > pos) {
            std::string entry = buffer.substr(pos, end - pos); // "NAME=VALUE"
            size_t eq = entry.find('=');
            std::string name =
                    (eq == std::string::npos) ? entry : entry.substr(0, eq);
            env_names.push_back(name);
        }

        pos = end + 1;
    }

    auto exists_in_proc = [&env_names](const char* var) -> bool {
        for (const auto& name : env_names) {
            if (name == var) {
                return true;
            }
        }
        return false;
    };

    /* -------- Step 2: for each argument, check existence via /proc and delete from __environ -------- */

    for (int i = 1; i < this->arg_num; ++i) {
        const char *var = this->arguments[i];
        if (!var) {
            continue;
        }

        // Check existence using /proc/<pid>/environ (as required)
        if (!exists_in_proc(var)) {
            std::cerr << "smash error: unsetenv: " << var << " does not exist"
                      << std::endl;
            return; // stop at first invalid occurrence
        }

        // Now actually remove it from __environ
        //bool found = false;

        for (int j = 0; __environ[j] != nullptr; ++j) {
            char *entry = __environ[j];            // "NAME=VALUE"
            char *eq_pos = strchr(entry, '=');
            size_t name_len = eq_pos ?
                              (size_t)(eq_pos - entry) :
                              strlen(entry);

            if (strlen(var) == name_len &&
                strncmp(entry, var, name_len) == 0) {

                // Shift entries left to remove this variable
                int k = j;
                while (__environ[k] != nullptr) {
                    __environ[k] = __environ[k + 1];
                    ++k;
                }
 //               found = true;
                break;
            }
        }

        // According to the HW, once a variable is successfully unset, it will
        // not be unset again, so "found == false" here should not happen.
        // We don't need extra error handling for that case.
    }
}


//////////////////////////////////////////SysInfoCommand////////////////////////////////


void SysInfoCommand::execute() {
    struct utsname uts;
    if (uname(&uts) == -1) {
        perror("smash error: uname failed");
        return;
    }

    struct sysinfo si;
    if (sysinfo(&si) == -1) {
        perror("smash error: sysinfo failed");
        return;
    }

    // 1. System name
    std::cout << "System: " << uts.sysname << std::endl;

    // 2. Hostname
    std::cout << "Hostname: " << uts.nodename << std::endl;

    // 3. Kernel (match assignment format — print only release)
    std::cout << "Kernel: " << uts.release << std::endl;

    // 4. Architecture
    std::cout << "Architecture: " << uts.machine << std::endl;

    // 5. Boot time
    time_t now = time(nullptr);
    time_t boot_time = now - si.uptime;

    struct tm bt;
    localtime_r(&boot_time, &bt);

    std::cout << "Boot Time: "
              << std::put_time(&bt, "%Y-%m-%d %H:%M:%S")
              << std::endl;
}

///////////////////////////////////////////////////////////////////RedirectionCommand/////////////////////////////////////////////
//ctor
RedirectionCommand::RedirectionCommand(const char *cmd_line)
        : Command(cmd_line)
{
    std::size_t pos;

    if ((pos = m_cmdline.find(">>")) != std::string::npos) {
        IO = ">>";

        std::string cmdPart = m_cmdline.substr(0, pos);
        arguments[0] = new char[cmdPart.size() + 1];
        std::strcpy(arguments[0], cmdPart.c_str());

        std::string filePart = _trim(m_cmdline.substr(pos + 2));
        arguments[2] = new char[filePart.size() + 1];
        std::strcpy(arguments[2], filePart.c_str());
    } else {
        IO = ">";

        pos = m_cmdline.find(">");
        std::string cmdPart = _trim(m_cmdline.substr(0, pos));
        arguments[0] = new char[cmdPart.size() + 1];
        std::strcpy(arguments[0], cmdPart.c_str());

        std::string filePart = _trim(m_cmdline.substr(pos + 1));
        arguments[2] = new char[filePart.size() + 1];
        std::strcpy(arguments[2], filePart.c_str());
    }
}

void RedirectionCommand::reset(int saved_fd) {
    if (dup2(saved_fd, STDOUT_FILENO) == -1) {
        perror("smash error: dup2 failed");
        return;
    }
    if (close(saved_fd) == -1) {
        perror("smash error: close failed");
        return;
    }
}

void RedirectionCommand::execute() {
    SmallShell& smash = SmallShell::getInstance();

    int backup_fd = dup(STDOUT_FILENO);
    if (backup_fd == -1) {
        perror("smash error: dup failed");
        return;
    }

    char* cmd      = arguments[0];
    char* filename = arguments[2];

    if (IO == ">>") {
        if (close(STDOUT_FILENO) == 0) {
            int fd = open(filename, O_APPEND | O_CREAT | O_WRONLY, 0666);
            if (fd == -1) {
                perror("smash error: open failed");
                reset(backup_fd);
                return;
            }
            smash.executeCommand(cmd);
            reset(backup_fd);
        } else {
            perror("smash error: close failed");
            return;
        }
    } else { // IO == ">"
        if (close(STDOUT_FILENO) == 0) {
            int fd = open(filename, O_TRUNC | O_CREAT | O_WRONLY, 0666);
            if (fd == -1) {
                perror("smash error: open failed");
                reset(backup_fd);
                return;
            }
            smash.executeCommand(cmd);
            reset(backup_fd);
        } else {
            perror("smash error: close failed");
            return;
        }
    }
}


///////////////////////////////////////////////////////////////////ListDirCommand/////////////////////////////////////////////
// Constructor
// ===== ListDirCommand implementation (same behavior, different style) =====

ListDirCommand::ListDirCommand(const char *cmd_line)
        : Command(cmd_line) {}

// Binary-compatible with the kernel struct, just formatted differently
struct linux_dirent64 {
    uint64_t       d_ino;
    int64_t        d_off;
    unsigned short d_reclen;
    unsigned char  d_type;
    char           d_name[];
};

// Keep alphabetical ordering helper but change style a bit
static void sortEntries(std::vector<std::string>& v) {
    std::sort(v.begin(), v.end(),
              [](const std::string& a, const std::string& b) {
                  return a < b;
              });
}

bool ListDirCommand::ReadDirLoop(std::vector<std::string>& entries, int dir_fd) {
    char   buf[4096];
    ssize_t nread = 0;

    // repeatedly call getdents64 until it returns 0 or −1
    while ((nread = syscall(SYS_getdents64, dir_fd, buf, sizeof(buf))) > 0) {
        std::size_t offset = 0;

        while (offset < static_cast<std::size_t>(nread)) {
            auto* ent = reinterpret_cast<linux_dirent64*>(buf + offset);
            std::string name(ent->d_name);

            if (name != "." && name != "..") {
                entries.push_back(name);
            }

            offset += ent->d_reclen;
        }
    }

    if (nread == -1) {
        perror("smash error: getdents64 failed");
        close(dir_fd);   // same as your original: close on error here
        return false;
    }

    return true;
}

void ListDirCommand::processDirectoryEntry(const std::string& dirPath,
                                           const std::string& entryName,
                                           int indentLevel) {
    // print name with tabs for indentation
    std::string prefix(indentLevel, '\t');
    std::cout << prefix << entryName << std::endl;

    // build full path and check if it is a directory
    std::string fullPath = dirPath;
    fullPath += "/";
    fullPath += entryName;

    struct stat st{};
    if (stat(fullPath.c_str(), &st) == 0 && S_ISDIR(st.st_mode)) {
        listDirectoryContents(fullPath, indentLevel + 1);
    }
}

void ListDirCommand::listDirectoryContents(const std::string& dirPath,
                                           int indentLevel) {
    int dir_fd = open(dirPath.c_str(), O_RDONLY | O_DIRECTORY);
    if (dir_fd == -1) {
        perror("smash error: open failed");
        return;
    }

    std::vector<std::string> entries;
    if (!ReadDirLoop(entries, dir_fd)) {
        // ReadDirLoop already closed dir_fd on error
        return;
    }

    // on success, close here exactly like before
    close(dir_fd);

    sortEntries(entries);

    for (const std::string& name : entries) {
        processDirectoryEntry(dirPath, name, indentLevel);
    }
}

void ListDirCommand::execute() {
    if (arg_num > 2) {
        std::cerr << "smash error: listdir: too many arguments" << std::endl;
        return;
    }

    std::string target;

    if (arg_num == 1) {
        char cwd[COMMAND_MAX_LENGTH];
        char* res = getcwd(cwd, sizeof(cwd));
        if (!res) {
            perror("smash error: getcwd failed");
            return;
        }
        target.assign(res);
    } else {
        target = arguments[1];
    }

    if (target.empty()) {
        target = ".";
    }

    listDirectoryContents(target, 0);
}
//////////////////////////////////////////WhoAmI////////////////////////////////
WhoAmICommand::WhoAmICommand(const char *cmd_line)
        : Command(cmd_line) {}


// helper: split one passwd line by ':' into fields[]
int WhoAmICommand::_parseColonSeparatedLine(const char *line, char **fields) {
    int idx = 0;
    const char *start = line;
    const char *end = nullptr;

    while ((end = strchr(start, ':')) != nullptr) {
        size_t len = end - start;

        fields[idx] = (char*)malloc(len + 1);
        strncpy(fields[idx], start, len);
        fields[idx][len] = '\0';

        idx++;
        start = end + 1;
    }

    // last field (home directory)
    fields[idx] = strdup(start);
    idx++;
    fields[idx] = nullptr;

    return idx;
}


void WhoAmICommand::execute() {
    uid_t uid = getuid();
    gid_t gid = getgid();

    // Open /etc/passwd
    int fd = open("/etc/passwd", O_RDONLY);
    if (fd < 0) {
        perror("smash error: open failed");
        return;
    }

    char buffer[4096];
    ssize_t read_bytes = read(fd, buffer, sizeof(buffer) - 1);
    close(fd);

    if (read_bytes < 0) {
        perror("smash error: read failed");
        return;
    }

    buffer[read_bytes] = '\0';

    // Parse file line-by-line
    char *line = strtok(buffer, "\n");
    while (line != nullptr) {
        char *fields[8] = {nullptr};
        int count = _parseColonSeparatedLine(line, fields);

        // passwd format:
        // 0: username
        // 1: x
        // 2: UID
        // 3: GID
        // 4: comment
        // 5: home directory
        if (count >= 6 && atoi(fields[2]) == (int)uid) {

            // print in REQUIRED order
            std::cout << fields[0] << std::endl;   // username
            std::cout << uid << std::endl;         // UID
            std::cout << gid << std::endl;         // GID
            std::cout << fields[5] << std::endl;   // home directory

            for (int i = 0; i < count; i++) {
                free(fields[i]);
            }
            return;
        }

        for (int i = 0; i < count; i++) {
            free(fields[i]);
        }

        line = strtok(nullptr, "\n");
    }

    std::cerr << "smash error: user not found" << std::endl;
}
//////////////////////////////////////////PipeCommand////////////////////////////////
//ctor
PipeCommand::PipeCommand(const char *cmd_line)
        : Command(cmd_line) {
    // Decide which kind of pipe we have: "|&" (stderr) or "|"
    if (m_cmdline.find("|&") != std::string::npos) {
        Type = "|&";
    } else {
        Type = "|";
    }
}

// helper
void PipeCommand::pipe_type_choose(std::string& leftCmd,
                                   std::string& rightCmd,
                                   int outFd) {
    SmallShell& smash = SmallShell::getInstance();

    int fds[2];
    if (pipe(fds) == -1) {
        perror("smash error: pipe failed");
        return;
    }

    // fds[0] – read side, fds[1] – write side

    /* ---------- first child: writer ---------- */
    pid_t writerPid = fork();
    if (writerPid == -1) {
        perror("smash error: fork failed");
        return;
    }

    if (writerPid == 0) {              // writer child
        if (dup2(fds[1], outFd) == -1) {
            perror("smash error: dup2 failed");
            return;
        }

        if (close(fds[0]) == -1) {     // close unused read end
            perror("smash error: close failed");
            return;
        }
        if (close(fds[1]) == -1) {     // close original write fd
            perror("smash error: close failed");
            return;
        }

        smash.executeCommand(leftCmd.c_str());
        exit(0);
    }

    /* ---------- second child: reader ---------- */
    pid_t readerPid = fork();
    if (readerPid == -1) {
        perror("smash error: fork failed");
        return;
    }

    if (readerPid == 0) {              // reader child
        if (dup2(fds[0], STDIN_FILENO) == -1) {
            perror("smash error: dup2 failed");
            return;
        }

        if (close(fds[1]) == -1) {     // close unused write end
            perror("smash error: close failed");
            return;
        }
        if (close(fds[0]) == -1) {
            perror("smash error: close failed");
            return;
        }

        smash.executeCommand(rightCmd.c_str());
        exit(0);
    }

    // parent – close both ends
    if (close(fds[1]) == -1) {
        perror("smash error: close failed");
        return;
    }
    if (close(fds[0]) == -1) {
        perror("smash error: close failed");
        return;
    }

    // wait for both children
    if (waitpid(writerPid, nullptr, 0) == -1) {
        perror("smash error: waitpid failed");
        return;
    }
    if (waitpid(readerPid, nullptr, 0) == -1) {
        perror("smash error: waitpid failed");
        return;
    }
}

void PipeCommand::execute() {
    std::string leftPart;
    std::string rightPart;

    // for "|": send stdout (1), for "|&": send stderr (2)
    int outFd = (Type == "|&") ? 2 : 1;

    if (Type == "|&") {
        size_t pos = m_cmdline.find("|&");
        leftPart  = m_cmdline.substr(0, pos);
        rightPart = m_cmdline.substr(pos + 2);
    } else {
        size_t pos = m_cmdline.find('|');
        leftPart  = m_cmdline.substr(0, pos);
        rightPart = m_cmdline.substr(pos + 1);
    }

    pipe_type_choose(leftPart, rightPart, outFd);
}














////////////////////////////////////

static unsigned long long du_recursive(const std::string& path) {
    struct stat st;
    if (lstat(path.c_str(), &st) == -1) {
        perror("smash error: lstat failed");
        return 0;
    }

    // Do not follow symbolic links
    if (S_ISLNK(st.st_mode)) {
        return 0;
    }

    unsigned long long total = st.st_size;

    // If it's a directory, recurse into its entries
    if (S_ISDIR(st.st_mode)) {
        DIR* dir = opendir(path.c_str());
        if (!dir) {
            perror("smash error: opendir failed");
            return total;  // at least count the directory itself
        }

        struct dirent* entry;
        while ((entry = readdir(dir)) != nullptr) {
            std::string name = entry->d_name;
            if (name == "." || name == "..") {
                continue;
            }
            std::string childPath = path + "/" + name;
            total += du_recursive(childPath);
        }

        if (closedir(dir) == -1) {
            perror("smash error: closedir failed");
        }
    }

    return total;
}
void DuCommand::execute() {
    // Error handling: more than one argument
    if (arg_num > 2) {
        std::cerr << "smash error: du: too many arguments" << std::endl;
        return;
    }

    // Determine directory path
    std::string path;
    if (arg_num == 1) {
        // No argument -> current working directory
        char cwd[PATH_MAX];
        if (!getcwd(cwd, sizeof(cwd))) {
            perror("smash error: getcwd failed");
            return;
        }
        path = cwd;
    } else {
        path = arguments[1];  // they guarantee it exists
    }

    // Recursively compute total size in bytes (without following symlinks)
    unsigned long long total_bytes = du_recursive(path);

    // Convert to whole kilobytes, rounding up
    unsigned long long total_kb = (total_bytes + 1023) / 1024;

    std::cout << "Total disk usage: " << total_kb << " KB" << std::endl;
}




///////////////////////////////////////
//////////////////////////////////////////NetInfo////////////////////////////////
//ctor
NetInfo::NetInfo(const char *cmd_line): Command(cmd_line){}

bool NetInfo::GetIPAddress(struct ifreq* ifr,int sock,const char* interface){
    //std::cout << sock << std::endl;
    if (ioctl(sock, SIOCGIFADDR, ifr) < 0) { // The result is stored in ifr.ifr_addr.
        close(sock);
        if (errno == ENODEV) {
            std::cerr << "smash error: netinfo: interface " << interface << " does not exist" << std::endl;
        } else {
            perror("smash error: ioctl failed");
        }
        return false;
    }
    return true;
}
bool NetInfo::GetSubnetMask(struct ifreq* ifr,int sock){
    if (ioctl(sock, SIOCGIFNETMASK, ifr) < 0) { // The result is stored in ifr.ifr_netmask.
        close(sock);
        perror("smash error: ioctl failed while fetching subnet mask");
        return false;
    }
    return true;
}
void NetInfo::printDefaultDns(){
    // Step 4: Get Default Gateway (Simulated)
    std::cout << "Default Gateway: 192.168.1.1" << std::endl;

    // Step 5: Simulate DNS Servers
    std::cout << "DNS Servers: 8.8.8.8, 8.8.4.4" << std::endl;

    return;
}
void NetInfo::displayNetworkInfo(const char *interface) {
    // Step 1: Create a socket
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("smash error: socket failed");
        return;
    }
    //std::cout << sock << std::endl;

    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, interface, IFNAMSIZ - 1);

    // Step 2: Get IP Address
    if(GetIPAddress(&ifr,sock,interface)==false)
        return;

    struct sockaddr_in *ip_addr = (struct sockaddr_in *)&ifr.ifr_addr;
    std::cout << "IP Address: " << inet_ntoa(ip_addr->sin_addr) << std::endl;

    // Step 3: Get Subnet Mask
    if(GetSubnetMask(&ifr,sock)==false)
        return;


    struct sockaddr_in *subnet_mask = (struct sockaddr_in *)&ifr.ifr_netmask;
    std::cout << "Subnet Mask: " << inet_ntoa(subnet_mask->sin_addr) << std::endl;

    printDefaultDns();

    close(sock);
}

void NetInfo::execute() {
    if (arg_num != 2) {
        std::cerr << "smash error: netinfo: interface not specified" << std::endl;
        return;
    }

    const char *interface = arguments[1];
    displayNetworkInfo(interface);
}



//////////////////////////////////////////////////usbinfo/////////////////
struct UsbDeviceInfo {
    int devnum;
    std::string vendor;
    std::string product;
    std::string manufacturer;
    std::string productName;
    std::string maxPower;
};

// small helper: read a sysfs file, trim whitespace, or return "N/A"
static std::string readSysfsFieldOrNA(const std::string& path) {
    int fd = open(path.c_str(), O_RDONLY);
    if (fd < 0) {
        return "N/A";
    }

    char buf[256];
    ssize_t n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) {
        return "N/A";
    }
    buf[n] = '\0';

    std::string s(buf);
    // trim whitespace
    size_t start = s.find_first_not_of(" \t\r\n");
    size_t end   = s.find_last_not_of(" \t\r\n");
    if (start == std::string::npos) {
        return "N/A";
    }
    return s.substr(start, end - start + 1);
}

void UsbInfo::execute() {
    // Arguments are ignored according to the spec, so no arg_num checks.

    const char* basePath = "/sys/bus/usb/devices";

    DIR* dir = opendir(basePath);
    if (!dir) {
        // If we can't read sysfs at all, treat as "no devices"
        std::cerr << "smash error: usbinfo: no USB devices found" << std::endl;
        return;
    }

    std::vector<UsbDeviceInfo> devices;

    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        std::string name = entry->d_name;
        if (name == "." || name == "..") {
            continue;
        }

        std::string devPath = std::string(basePath) + "/" + name;

        // devnum identifies "real" USB device entries
        std::string devnumStr = readSysfsFieldOrNA(devPath + "/devnum");
        if (devnumStr == "N/A") {
            continue; // not a USB device directory
        }

        UsbDeviceInfo info;
        info.devnum = std::atoi(devnumStr.c_str());

        info.vendor       = readSysfsFieldOrNA(devPath + "/idVendor");
        info.product      = readSysfsFieldOrNA(devPath + "/idProduct");
        info.manufacturer = readSysfsFieldOrNA(devPath + "/manufacturer");
        info.productName  = readSysfsFieldOrNA(devPath + "/product");

        // Max power may be stored as "bMaxPower" or "maxpower", try both
        info.maxPower = readSysfsFieldOrNA(devPath + "/bMaxPower");
        if (info.maxPower == "N/A") {
            info.maxPower = readSysfsFieldOrNA(devPath + "/maxpower");
        }

        devices.push_back(info);
    }

    closedir(dir);

    if (devices.empty()) {
        std::cerr << "smash error: usbinfo: no USB devices found" << std::endl;
        return;
    }

    // sort by devnum ascending
    std::sort(devices.begin(), devices.end(),
              [](const UsbDeviceInfo& a, const UsbDeviceInfo& b) {
                  return a.devnum < b.devnum;
              });

    // print each device
    for (const auto& d : devices) {
        std::string vendor   = (d.vendor       == "N/A") ? "N/A" : d.vendor;
        std::string product  = (d.product      == "N/A") ? "N/A" : d.product;
        std::string manuf    = (d.manufacturer == "N/A") ? "N/A" : d.manufacturer;
        std::string prodName = (d.productName  == "N/A") ? "N/A" : d.productName;
        std::string power    = (d.maxPower     == "N/A") ? "N/A" : d.maxPower;

        std::cout << "Device " << d.devnum << ": ID "
                  << vendor << ":" << product << " "
                  << manuf << " " << prodName
                  << " MaxPower: " << power << std::endl;
    }
}

//////////////////////////////////////////SmallShell///////////////////////////////
SmallShell::SmallShell() : def_msg("smash> "), LastDir(""), ShellJobs(new JobsList()) {
// TODO: add your implementation

}

SmallShell::~SmallShell() {
// TODO: add your implementation
}
////////////////////////////////////////////















/**
* Creates and returns a pointer to Command class which matches the given command line (cmd_line)
*/





/**
* Creates and returns a pointer to Command class which matches the given command line (cmd_line)
*/


Command* SmallShell::CreateCommand(const char* cmd_line, std::string aliased_cmd_line) {
    // Retain the provided initialization logic
    string cmd_s = _trim(string(cmd_line));


    if (cmd_s.empty()) {
        return nullptr;
    }


    string firstWord = cmd_s.substr(0, cmd_s.find_first_of(" \n"));


    // Built-in commands ignore ampersand
    char* CommandWithoutAmpersand = new char[COMMAND_MAX_LENGTH];
    strcpy(CommandWithoutAmpersand, cmd_line);
    _removeBackgroundSign(CommandWithoutAmpersand);
    _trim(CommandWithoutAmpersand);


    // Call the auxiliary function with provided parameters
    return CreateCommand_aux(cmd_line,cmd_s, firstWord, CommandWithoutAmpersand, aliased_cmd_line);
}






Command* SmallShell::CreateCommand_aux(
        const char* cmd_line,
        const std::string& cmd_s,
        const std::string& firstWord,
        char* CommandWithoutAmpersand,
        const std::string& aliased_cmd_line
) {
    if (PIPE_redirection(cmd_s)) {
        return new PipeCommand(CommandWithoutAmpersand);
    } else if (IO_redirection(cmd_s) ) {
        return new RedirectionCommand(CommandWithoutAmpersand);
    } else if (firstWord.compare("pwd") == 0 || firstWord.compare("pwd&") == 0) {
        return new GetCurrDirCommand(CommandWithoutAmpersand);
    } else if (firstWord.compare("showpid") == 0 || firstWord.compare("showpid&") == 0) {
        return new ShowPidCommand(CommandWithoutAmpersand);
    } else if (firstWord.compare("chprompt") == 0 || firstWord.compare("chprompt&") == 0) {

        if(cmd_s=="chprompt &")
            return new ChPrompt(cmd_s.c_str());
        else return new ChPrompt(CommandWithoutAmpersand);
    } else if (firstWord.compare("cd") == 0 || firstWord.compare("cd&") == 0) {
        return new ChangeDirCommand(CommandWithoutAmpersand, &LastDir);
    } else if (firstWord.compare("jobs") == 0 || firstWord.compare("jobs&") == 0) {
        return new JobsCommand(CommandWithoutAmpersand, ShellJobs);
    } else if (firstWord.compare("fg") == 0 || firstWord.compare("fg&") == 0) {
        return new ForegroundCommand(CommandWithoutAmpersand, ShellJobs);
    } else if (firstWord.compare("quit") == 0 || firstWord.compare("quit&") == 0) {
        return new QuitCommand(CommandWithoutAmpersand, ShellJobs);
    } else if (firstWord.compare("kill") == 0 || firstWord.compare("kill&") == 0) {
        return new KillCommand(CommandWithoutAmpersand, ShellJobs);
    } else if (firstWord.compare("alias") == 0 || firstWord.compare("alias&") == 0) {
        return new aliasCommand(CommandWithoutAmpersand, &AliasMap, &AliasList);
    } else if (firstWord.compare("unalias") == 0 || firstWord.compare("unalias&") == 0) {
        return new unaliasCommand(CommandWithoutAmpersand, &AliasMap, &AliasList);
    }  else if (firstWord.compare("unsetenv") == 0 || firstWord.compare("unsetenv&") == 0) {
        return new UnsetEnvCommand(CommandWithoutAmpersand);
    }  else if (std::find(AliasList.begin(), AliasList.end(), firstWord) != AliasList.end()) {
        std::string aliased = std::string(cmd_s);
        std::string aliasValue = AliasMap[firstWord] + _trim(aliased).substr(firstWord.length());
        std::string real_cmd_line = aliasValue.c_str();
        return CreateCommand(real_cmd_line.c_str(), cmd_s); // Recursively handle aliases
    } else if (firstWord.compare("listdir") == 0 || firstWord.compare("listdir&") == 0) {
        return new ListDirCommand(CommandWithoutAmpersand);
    } else if (firstWord.compare("whoami") == 0 || firstWord.compare("whoami&") == 0) {
        return new WhoAmICommand(CommandWithoutAmpersand);
    } else if (firstWord.compare("sysinfo") == 0 || firstWord.compare("sysinfo&") == 0) {
        return new SysInfoCommand(CommandWithoutAmpersand);
    } else if (firstWord.compare("usbinfo") == 0 || firstWord.compare("usbinfo&") == 0) {
        return new UsbInfo(CommandWithoutAmpersand);
    } else if (firstWord.compare("netinfo") == 0 || firstWord.compare("netinfo&") == 0) {
        return new NetInfo(CommandWithoutAmpersand);
    } else if (firstWord == "du" || firstWord == "du&") {
        return new DuCommand(CommandWithoutAmpersand);
    } else { // External command
        return new ExternalCommand(cmd_line, aliased_cmd_line);
    }
}


void SmallShell::executeCommand(const char *cmd_line) {
    // TODO: Add your implementation here

    Command* cmd = CreateCommand(cmd_line);

    if(cmd== nullptr)
        return;

    cmd->execute();


    // for example:
    // Command* cmd = CreateCommand(cmd_line);
    // cmd->execute();
    // Please note that you must fork smash process for some commands (e.g., external commands....)
}

bool SmallShell::IO_redirection(const std::string& new_msg) const {

    if(new_msg.find(">") != std::string::npos && (InQuotes(new_msg, ">") || BeforeEqual(new_msg, new_msg.find(">"))))
        return false;
    if(new_msg.find(">>") != std::string::npos && (InQuotes(new_msg, ">>") || BeforeEqual(new_msg, new_msg.find(">>"))))
        return false;

    // Check if '>' or '>>' exists in the string
    if (new_msg.find(">") != std::string::npos || new_msg.find(">>") != std::string::npos) {
        return true; // Redirection found
    }
    return false; // No redirection
}

bool SmallShell::PIPE_redirection(const std::string& new_msg) const {

    if(new_msg.find("|") && (InQuotes(new_msg,"|") || BeforeEqual(new_msg,new_msg.find("|"))))
        return false;
    if(new_msg.find("|&") && (InQuotes(new_msg,"|&") || BeforeEqual(new_msg,new_msg.find("|&"))))
        return false;

    // Check if '|' or '|&' exists in the string
    if (new_msg.find("|") != std::string::npos || new_msg.find("|&") != std::string::npos){
        return true; // Redirection found
    }
    return false; // No redirection
}

bool SmallShell::InQuotes(const std::string& new_msg, const std::string& symbol) const {
    if (new_msg.find('\'') != std::string::npos && new_msg.find(symbol) != std::string::npos) {
        size_t posLessThan = new_msg.find(symbol);
        size_t posBefore = new_msg.rfind('\'', posLessThan - 1); // Find ' before '<'
        size_t posAfter = new_msg.find('\'', posLessThan + 1);   // Find ' after '<'

        if (posBefore != std::string::npos && posAfter != std::string::npos) {
            // Both ' exist before and after '<'
            return true;
        }
    }
    return false;
}

bool SmallShell::BeforeEqual(const std::string& new_msg, size_t symbolIndex) const {
    size_t equalIndex = new_msg.find("=");

    // Check if '=' exists and is directly after the symbol at symbolIndex
    if (equalIndex != std::string::npos && equalIndex - 1 == symbolIndex) {
        return true;
    }
    return false;
}






