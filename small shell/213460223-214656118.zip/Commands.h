#ifndef SMASH_COMMAND_H_
#define SMASH_COMMAND_H_

#include <vector>
#include <map>
#include <list>
#include <set>
#include <memory>
#define COMMAND_MAX_LENGTH (200)
#define COMMAND_MAX_ARGS (20)

class Command {
protected:
    int arg_num;
    char* arguments[COMMAND_MAX_ARGS+1];
    std::string m_cmdline;
    //   std::string m_aliased;
public:
    Command(const char *cmd_line);

    virtual ~Command();

    virtual void execute() = 0;
    // TODO: Add your extra methods if needed
    std::string get_cmdline() const;




};

////////////////////////////////////////////Commands/////////////////////////////////////

class BuiltInCommand : public Command {

public:
    BuiltInCommand(const char *cmd_line);
    virtual ~BuiltInCommand() {
    }
};

class ExternalCommand : public Command {
    std::string aliased_cmd_line;
public:
    ExternalCommand(const char *cmd_line,std::string aliased_cmd_line);
    virtual ~ExternalCommand() {
    }
    void execute() override;
    bool containsNoWildcard(const std::string& cmdline) const;
};

class PipeCommand : public Command {
    // TODO: Add your data members
    std::string Type;
public:
    PipeCommand(const char *cmd_line);
    virtual ~PipeCommand() {
    }
    void execute() override;
    void pipe_type_choose(std::string& firstCommand,std::string& secondCommand,int type);
};

class RedirectionCommand : public Command {
    // TODO: Add your data members
    std::string IO;
public:
    explicit RedirectionCommand(const char *cmd_line);
    virtual ~RedirectionCommand() {
    }
    void execute() override;
    void reset(int FD);
};

//////////////////////////////////////////////////////BuiltInCommands//////////////////////////////////////////////

////////////////////////////////////ChPrompt///////////////////////////////
class ChPrompt:public BuiltInCommand{
public:
    ChPrompt(const char *cmd_line);
    virtual ~ChPrompt() =default;
    void execute() override;
};


////////////////////////////////////ChangeDirCommand///////////////////////////////
class ChangeDirCommand : public BuiltInCommand {
private:
    std::string *LastDir;
public:
    ChangeDirCommand(const char *cmd_line, std::string *plastPwd);
    virtual ~ChangeDirCommand() {}
    bool check_for_errors();
    void execute() override;
};

////////////////////////////////////GetCurrDirCommand///////////////////////////////
class GetCurrDirCommand : public BuiltInCommand {
public:
    GetCurrDirCommand(const char *cmd_line);
    virtual ~GetCurrDirCommand() {}
    void execute() override;
};

////////////////////////////////////ShowPidCommand///////////////////////////////
class ShowPidCommand : public BuiltInCommand {
public:
    ShowPidCommand(const char *cmd_line);
    virtual ~ShowPidCommand() {}
    void execute() override;
};

class JobsList;

////////////////////////////////////QuitCommand////////////////////////////////
class QuitCommand : public BuiltInCommand {
    // TODO: Add your data members public:
    JobsList *jobs;
public:
    QuitCommand(const char *cmd_line, JobsList *jobs);
    virtual ~QuitCommand() {}
    void execute() override;
};


class JobsList {
public:
    class JobEntry {
        // TODO: Add your data members
    public:
        int ID;
        pid_t PID;
        std::string cmd;

        JobEntry(int ID, pid_t PID, const std::string &cmd)
                : ID(ID), PID(PID),cmd(cmd) {}
        ~JobEntry()=default;
    };

    // TODO: Add your data members
    std::map<int, std::shared_ptr<JobEntry>> jobs ;
public:
    JobsList();

    ~JobsList()=default;

    void addJob(Command *cmd,pid_t job_pid ,bool isStopped = false,std::string aliased_cmd_line="");

    void printJobsList();

    void printJobsList_byPID(); // i added this function, (used in quit command)

    void killAllJobs();

    void removeFinishedJobs();

    JobEntry *getJobById(int jobId);

    void removeJobById(int jobId);

    JobEntry *getLastJob(int *lastJobId);

    JobEntry *getLastStoppedJob(int *jobId);

    // TODO: Add extra methods or modify exisitng ones as needed
};

class JobsCommand : public BuiltInCommand {
    // TODO: Add your data members
    JobsList *jobs;

public:
    JobsCommand(const char *cmd_line, JobsList *jobs);

    virtual ~JobsCommand() {
    }

    void execute() override;
};

class KillCommand : public BuiltInCommand {
    // TODO: Add your data members
    JobsList *jobs;
public:
    KillCommand(const char *cmd_line, JobsList *jobs);

    virtual ~KillCommand() {
    }

    bool prepare();
    void execute() override;
};

class ForegroundCommand : public BuiltInCommand {
    // TODO: Add your data members
    JobsList *jobs;
public:
    ForegroundCommand(const char *cmd_line, JobsList *jobs);

    virtual ~ForegroundCommand() {
    }

    void execute() override;
};

class UnsetEnvCommand : public BuiltInCommand {
public:
    UnsetEnvCommand(const char *cmd_line);

    virtual ~UnsetEnvCommand() {
    }

    void execute() override;
};

class SysInfoCommand : public BuiltInCommand {
public:
    SysInfoCommand(const char *cmd_line) : BuiltInCommand(cmd_line) {}

    virtual ~SysInfoCommand() { }

    void execute() override;
};

class DuCommand : public BuiltInCommand {
public:
    DuCommand(const char* cmd_line) : BuiltInCommand(cmd_line) {}
    virtual ~DuCommand() {}
    void execute() override;
};




class ListDirCommand : public Command {
public:
    ListDirCommand(const char *cmd_line);

    virtual ~ListDirCommand() {
    }

    void execute() override;
    // Helper function for listing directories
    bool ReadDirLoop( std::vector<std::string>& entries,int dir_fd);
    void listDirectoryContents(const std::string& dirPath, int indentLevel);
    // bool isDirectory(const std::string& path);



    void processDirectoryEntry(const std::string& dirPath,const std::string& entryName,int indentLevel);



};

class UsbInfo : public Command {
public:
    UsbInfo(const char *cmd_line) : Command(cmd_line) {}
    virtual ~UsbInfo() {}

    void execute() override;
};
class WhoAmICommand : public Command {
public:
    WhoAmICommand(const char *cmd_line);

    int _parseColonSeparatedLine(const char *line, char **fields);
    virtual ~WhoAmICommand() {
    }

    void execute() override;

    char* allocateAndCopySubstring(const char* start, size_t len);
};

class NetInfo : public Command {
    // TODO: Add your data members
public:
    NetInfo(const char *cmd_line);

    virtual ~NetInfo() {
    }
    bool GetIPAddress( struct ifreq* ifr, int sock,const char* interface);
    bool GetSubnetMask( struct ifreq* ifr, int sock);
    void printDefaultDns();

    void displayNetworkInfo(const char *interface);
    void execute() override;
};

class aliasCommand : public BuiltInCommand {
    std::map<std::string ,std::string > *m_AliasMap;
    std::list<std::string> *m_AliasList;
public:
    aliasCommand(const char *cmd_line,std::map<std::string ,std::string > *m_AliasMap,std::list<std::string> *m_AliasList);

    virtual ~aliasCommand() {
    }

    bool regex_check();
    void execute() override;
};

class unaliasCommand : public BuiltInCommand {
    std::map<std::string ,std::string > *m_AliasMap;
    std::list<std::string> *m_AliasList;
public:
    unaliasCommand(const char *cmd_line,std::map<std::string ,std::string > *m_AliasMap,std::list<std::string> *m_AliasList);

    virtual ~unaliasCommand() {
    }

    void execute() override;
};

/////////////////////////////////////////SmallShell//////////////////////////////////////////////////

class SmallShell {
private:
    // TODO: Add your data members
    std::string def_msg;
    std::string LastDir;
    JobsList *ShellJobs;
    JobsList::JobEntry *CurrRunningJob;
    std::map<std::string ,std::string > AliasMap;
    std::list<std::string> AliasList;


    SmallShell();

public:
    Command *CreateCommand(const char *cmd_line,std::string aliased_cmd_line ="");

    Command *CreateCommand_aux(
            const char *cmd_line,
            const std::string& cmd_s,
            const std::string& firstWord,
            char* CommandWithoutAmpersand,
            const std::string& aliased_cmd_line);




    SmallShell(SmallShell const &) = delete; // disable copy ctor
    void operator=(SmallShell const &) = delete; // disable = operator
    static SmallShell &getInstance() // make SmallShell singleton
    {
        static SmallShell instance; // Guaranteed to be destroyed.
        // Instantiated on first use.
        return instance;
    }

    ~SmallShell();

    void executeCommand(const char *cmd_line);

    // TODO: add extra methods as needed
    const std::string& get_def_msg(){
        return def_msg;
    }

    JobsList* getJobList(){
        return ShellJobs;
    }
    JobsList::JobEntry  *getCurrRunningJob(){
        return this->CurrRunningJob;
    }

    const std::string alias_cmd( const std::string& value) {
        for (const auto& p : AliasMap) {
            auto key=p.first;
            auto mappedValue=p.second;
            if (mappedValue == value) {
                return key; // Return the key when the value matches
            }
        }
        return ""; // Return an empty string if no match is found
    }


    void set_def_msg(const std::string& new_msg){
        this->def_msg=new_msg;
    }
    void setCurrRunningJob(JobsList::JobEntry *CurrRunningJob){
        this->CurrRunningJob=CurrRunningJob;
    }

    bool IO_redirection(const std::string& new_msg) const;
    bool PIPE_redirection(const std::string& new_msg) const;

    bool InQuotes(const std::string& new_msg,const std::string& symbol) const;
    bool BeforeEqual(const std::string& new_msg,size_t symbolIndex) const;

};



#endif //SMASH_COMMAND_H_
