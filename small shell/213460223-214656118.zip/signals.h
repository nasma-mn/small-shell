#ifndef SMASH__SIGNALS_H_
#define SMASH__SIGNALS_H_
#include "Commands.h"
#include <unistd.h>
void ctrlCHandler(int sig_num);

void jobDeal(JobsList::JobEntry *job);

#endif //SMASH__SIGNALS_H_
