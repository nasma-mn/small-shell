#include <iostream>
#include <signal.h>
#include "signals.h"



using namespace std;

void jobDeal(JobsList::JobEntry *job){

    if (kill(job->PID, SIGKILL) == 0) {  // Check if syscall succeeded
        std::cout << "smash: process " << job->PID << " was killed" << std::endl;
        delete SmallShell::getInstance().getCurrRunningJob();
        SmallShell::getInstance().setCurrRunningJob(nullptr);
    } else {
        perror("smash error: kill failed");  // If syscall fails
    }

}

void ctrlCHandler(int sig_num) {
    // TODO: Add your implementation
    std::cout << "smash: got ctrl-C" << std::endl;
    JobsList::JobEntry *job = SmallShell::getInstance().getCurrRunningJob();
    if (job != nullptr)
        jobDeal(job);

}
